import { Game } from "./game";
import ReactDOM from "react-dom";

ReactDOM.render(<Game />, document.getElementById("root"));
